from django.apps import AppConfig


class ProcessdataConfig(AppConfig):
    name = 'processdata'
